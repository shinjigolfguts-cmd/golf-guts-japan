import json,re,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1];W=R/'docs/research/deep'
def read(p):
 s=p.read_text();return json.loads(s[s.index('{'):].rstrip(';\n'))
d=read(R/'docs/research/deep-baseline.js');by={c['id']:c for c in d['courses']};changes=[];skipped=[]
for region in ['north','chubu','kinki','chugoku','kyushu','kanto','gdo-chubu','featured']:
 p=W/('deep-'+region+'.json')
 if not p.exists():continue
 rows=json.loads(p.read_text())
 if isinstance(rows,dict):rows=rows.get('courses',rows.get('updates',[]))
 for row in rows:
  if not row.get('comparison'):continue
  c=by.get(row['id']);assert c and c['name']==row['name'],row
  if row.get('pref'):assert c['area'].startswith(row['pref']),row
  for key,f in row.get('comparison',{}).items():
   if not f:continue
   assert key in c['comparison'] and f.get('text') and re.match('https?://',f.get('url','')),row
   if f.get('priceVerified'):assert f.get('priceLabel') and f.get('conditions'),row
   old=c['comparison'].get(key)
   verified_budget_update=key=='budget' and f.get('updateExisting') is True and f.get('priceVerified') is True
   if region!='featured' and old and not verified_budget_update:
    skipped.append({'id':c['id'],'key':key,'reason':'既存情報を保持'});continue
   c['comparison'][key]=f;changes.append({'id':c['id'],'name':c['name'],'key':key,'url':f['url'],'filled':not bool(old)})
  if region=='featured' and row.get('aspiration'):c['aspiration']=row['aspiration']
# GDO's current title explicitly marks this identity closed; retain its record,
# but never suggest it as a playable result.
closed=by[1265]
closed['unavailable']=True
closed['serviceNotice']='GDOの施設名に「閉鎖」と明記されています（2026-10-25確認）。プレー候補には含めていません。過去の施設情報として掲載しています。'
closed['url']='https://reserve.golfdigest.co.jp/golf-course/736101/'
closed['sources'].append({'label':'閉鎖表記の確認先（GDO）','url':closed['url']})
for cat in d['categories']:
 if cat.get('key')=='dream':cat['reasons']=[by[i].get('aspiration',{}).get('reason',by[i]['feature']) for i in cat['ids']]
d['updated']='2026-10-25';(R/'dist/data.js').write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
a={'total':len(by),'changedFields':len(changes),'coursesChanged':len(set(x['id'] for x in changes)),'newFields':sum(x['filled'] for x in changes),'coverage':{key:sum(bool(c['comparison'].get(key)) for c in by.values()) for key in ['play','car','rail','scenery','dining','budget','stay']},'changes':changes,'existingPreserved':skipped}
(R/'docs/deep-research-audit.json').write_text(json.dumps(a,ensure_ascii=False,indent=2));print({k:v for k,v in a.items() if k not in ['changes','existingPreserved']})

# Retain later independently verified corrections after enrichment regeneration.
import subprocess
subprocess.run(['python', str(R/'scripts/apply-access-audit.py')],check=True)
