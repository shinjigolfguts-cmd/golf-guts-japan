"""Apply source-backed access corrections; preserve prior evidence for repeatable rebuilds."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1];p=R/'dist/data.js';d=json.loads(p.read_text().removeprefix('const DATA=').rstrip(';\n'));by={x['id']:x for x in d['courses']};audit={'changes':sum([json.loads((R/'docs'/n).read_text())['changes'] for n in ['access-audit-20261025.json','access-audit-20261025-batch2.json','access-audit-20261026.json']],[])}
for change in audit['changes']:
 o=by[change['id']];keys=change['path'].split('.')
 for k in keys[:-1]:o=o[k]
 o[keys[-1]]=change['after']
p.write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
print('access audit corrections applied',len(audit['changes']))
