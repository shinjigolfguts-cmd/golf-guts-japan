"""Verified corrections after the v8 independent audit; safe to rerun after rebuilding data."""
import json
from pathlib import Path
from urllib.parse import urlparse
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'dist/data.js';d=json.loads(p.read_text().removeprefix('const DATA=').rstrip(';\n'))
non_facility_hosts={'www.hga.gr.jp','www.pref.aomori.lg.jp','tga54.com','www.golf.fukui.jp','www.pref.iwate.jp','www.pref.fukushima.lg.jp','www.guk.jp','www.kanko-miyazaki.jp','okinawasportsisland.jp'}
changes=[]
for c in d['courses']:
 u=c.get('officialUrl')
 if u and urlparse(u).netloc in non_facility_hosts:
  changes.append({'id':c['id'],'name':c['name'],'field':'officialUrl','before':u,'after':None,'reason':'加盟団体・自治体・観光情報を施設自身の公式サイトと誤表示しない。元の出典は保存。'})
  c['officialUrl']=None
fixes={365:{'officialUrl':'https://www.noshirocountryclub.com/'},776:{'officialUrl':'https://www.clark-cc.jp/'},781:{'officialUrl':'https://gozensui-gc.com/'},1353:{'area':'鹿児島県・霧島市'},801:{'name':'定山渓カントリー倶楽部 駒丘コース','officialUrl':'https://jozankei-cc.jp/'}}
for c in d['courses']:
 for key,value in fixes.get(c['id'],{}).items():
  if c.get(key)!=value:
   changes.append({'id':c['id'],'field':key,'before':c.get(key),'after':value})
   c[key]=value
notice='2026年のニセコビレッジゴルフコースの営業は9月30日で終了しました（公式10月2日告知）。次シーズンの営業・予約開始は公式案内をご確認ください。別施設のニセコゴルフコースとは営業日が異なります。'
notice_url='https://www.niseko-village.com/ja/%E3%83%8B%E3%82%BB%E3%82%B3%E3%83%93%E3%83%AC%E3%83%83%E3%82%B8%E3%82%B4%E3%83%AB%E3%83%95%E3%82%B3%E3%83%BC%E3%82%B9%E3%83%BBpure-%E4%BB%8A%E3%82%B7%E3%83%BC%E3%82%BA%E3%83%B3%E3%81%AE%E5%96%B6/'
niseko=next(c for c in d['courses'] if c['id']==178)
if niseko.get('serviceNotice')!=notice:
 changes.append({'id':178,'field':'serviceNotice','before':niseko.get('serviceNotice'),'after':notice,'source':notice_url})
 niseko['serviceNotice']=notice
if not any(x['url']==notice_url for x in niseko.get('sources',[])):niseko.setdefault('sources',[]).append({'label':'公式2026年シーズン営業終了案内','url':notice_url})
p.write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
log=ROOT/'docs/independent-audit-20261025.json'
if changes:
 old=json.loads(log.read_text()) if log.exists() else {'baseline':'v8 / 810256210bb124d4b68713b99b12ed62d2905a85','changes':[]}
 old['changes']+=changes;log.write_text(json.dumps(old,ensure_ascii=False,indent=2))
print('data corrections',len(changes))
# Keep the next independently reviewed access batch after baseline corrections.
import subprocess,sys
subprocess.run([sys.executable,str(ROOT/'scripts/apply-access-audit.py')],check=True)
