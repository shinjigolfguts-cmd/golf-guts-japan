"""Build crawlable, shareable pages from the existing verified records; no fact invention."""
import json,re,html,hashlib,os
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1];D=R/'dist'
def readjs(p):
 s=p.read_text();return json.loads(s[s.index('=')+1:].strip().rstrip(';'))
data=readjs(D/'data.js');regions=readjs(D/'regions.js')
origin=os.getenv('SITE_ORIGIN','https://guts-japan-golf-guide.golfguts0702.chatgpt.site').rstrip('/')
assert re.fullmatch(r'https://[A-Za-z0-9.-]+(?:/[A-Za-z0-9_/-]+)?',origin)
def public_path(path):
 if os.getenv('SITE_CLEAN_URLS','1')=='0':return path
 return '' if path=='index.html' else path.removesuffix('.html')
today=datetime.now(ZoneInfo('Asia/Tokyo')).date().isoformat();esc=lambda s:html.escape(str(s or ''),quote=True)
prefs={name:en.lower() for _,ps in regions for name,en in ps};by={x['id']:x for x in data['courses']}
fields=[('scenery','景色・ロケーション'),('play','プレーの特徴'),('car','車でのアクセス'),('rail','電車・駅から'),('dining','食事'),('stay','宿泊・お風呂'),('budget','予算の目安')]
statefile=R/'docs/maintenance/page-state.json';old=json.loads(statefile.read_text()) if statefile.exists() else {};state={};entries=[]
def write(path,title,description,body,breadcrumbs,unavailable=False,extra=''):
 url=origin+'/'+public_path(path);prefix='../' if '/' in path else './'
 crumbs=[{'@type':'ListItem','position':i+1,'name':n,'item':origin+'/'+public_path(u)} for i,(n,u) in enumerate(breadcrumbs)]
 schema={'@context':'https://schema.org','@graph':[{'@type':'WebPage','name':title,'description':description,'url':url,'inLanguage':'ja'},{'@type':'BreadcrumbList','itemListElement':crumbs}]}
 markup=f'''<!doctype html><html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)} | GOLF GUTS</title><meta name="description" content="{esc(description)}"><link rel="canonical" href="{url}"><meta property="og:type" content="website"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:url" content="{url}"><meta name="twitter:card" content="summary"><link rel="stylesheet" href="{prefix}guide.css">{'<meta name="robots" content="noindex,follow">' if unavailable else ''}<script type="application/ld+json">{json.dumps(schema,ensure_ascii=False).replace('<','\\u003c')}</script></head><body><header><a class="brand" href="{prefix}index.html">GOLF GUTS<small>DESIGN YOUR GOLF LIFE</small></a><a href="{prefix}find.html">４コースを見つける</a></header><main><nav class="breadcrumbs" aria-label="現在位置">{' <span aria-hidden="true">／</span> '.join(f'<a href="{prefix}{u}">{esc(n)}</a>' for n,u in breadcrumbs)}</nav>{body}</main><footer><a href="{prefix}directory.html">全国・都道府県別一覧</a><a href="{prefix}editorial.html">掲載方針・情報の見方</a><p>GOLF GUTS — DESIGN YOUR GOLF LIFE</p></footer>{extra}</body></html>'''
 p=D/path;p.parent.mkdir(exist_ok=True,parents=True);p.write_text(markup)
 digest=hashlib.sha256(markup.encode()).hexdigest();lastmod=old.get(path,{}).get('lastmod',today) if old.get(path,{}).get('hash')==digest else today
 state[path]={'hash':digest,'lastmod':lastmod}
 if not unavailable:entries.append((url,lastmod))
def card(c,prefix):
 return f'<li><a class="course-link" href="{prefix}courses/{c["id"]}.html"><span>{esc(c["area"])}</span><h2>{esc(c["name"])}</h2><p>{esc(c["feature"])}</p>{"<strong>閉鎖表記あり・プレー候補外</strong>" if c.get("unavailable") else ""}<b>詳細を見る →</b></a></li>'
for c in data['courses']:
 pref=next(p for p in prefs if c['area'].startswith(p));slug=prefs[pref]
 body=f'<p class="eyebrow">JAPAN GOLF GUIDE · {esc(c["area"])}</p><h1>{esc(c["name"])}</h1><p class="lead">{esc(c["feature"])}</p>'
 if c.get('serviceNotice'):body+=f'<aside class="notice">{esc(c["serviceNotice"])}</aside>'
 if c.get('aspiration'):
  a=c['aspiration'];body+=f'<aside class="notice"><strong>{esc(a.get("accessLabel"))}</strong><p>{esc(a.get("accessNote"))}</p><a href="{esc(a.get("sourceUrl"))}" target="_blank" rel="noopener noreferrer">利用条件の根拠 ↗</a></aside>'
 body+=f'<div class="actions"><button data-save="{c["id"]}" aria-pressed="false" hidden>♡ 保存する</button><button data-share hidden>このページのURLをコピー</button><span id="action-status" role="status"></span></div><div class="facts">'
 for key,label in fields:
  f=c.get('comparison',{}).get(key);body+=f'<section><h2>{label}</h2>'
  if f:
   if f.get('priceVerified'):body+=f'<p class="price">{esc(f.get("priceLabel"))}</p>'
   body+=f'<p>{esc(f["text"])}</p>'
   if f.get('conditions') and f['conditions'] not in f['text']:body+=f'<p>{esc(f["conditions"])}</p>'
   labelsrc={'official':'公式の案内','booking':'予約サイトの施設・プラン情報','review':'口コミの根拠'}.get(f.get('sourceType'),'根拠の案内')
   body+=f'<a href="{esc(f["url"])}" target="_blank" rel="noopener noreferrer">{labelsrc} ↗</a><p class="date">情報確認：{esc(f.get("checked","不明"))}</p>'
  else:body+='<p class="muted">この項目の詳しい情報は不明です。確認できていない内容は掲載していません。</p>'
  if key=='budget':body+='<p class="date">掲載金額は確認時の例です。18ホール・ハーフ・宿泊付きの違い、食事・税・人数割増を含む予約日の総額をご確認ください。</p>'
  body+='</section>'
 body+='</div><section class="reservation"><h2>予約前に</h2><p>'+esc(c['note'])+'</p>'
 if not c.get('unavailable'):
  for key,label in [('officialUrl','公式サイト'),('bookingUrl','予約サイト')]:
   if c.get(key):body+=f'<a class="button" href="{esc(c[key])}" target="_blank" rel="noopener noreferrer">{label}で確認 ↗</a>'
 body+='</section><section><h2>確認した情報</h2><ul class="sources">'+''.join(f'<li><a href="{esc(s["url"])}" target="_blank" rel="noopener noreferrer">{esc(s["label"])}</a></li>' for s in c.get('sources',[]))+'</ul></section>'
 body+=f'<a class="button" href="../prefectures/{slug}.html">{pref}のコースをもっと見る →</a>'
 write(f'courses/{c["id"]}.html',c['name']+'｜'+pref+'のゴルフ場',c['area']+'の'+c['name']+'。'+c['feature'][:120]+' 景観・食事・交通・料金・宿泊を出典付きで確認。',body,[('全国','index.html'),(pref,f'prefectures/{slug}.html'),(c['name'],f'courses/{c["id"]}.html')],c.get('unavailable',False),'<script src="../course-page.js" defer></script>')
for pref,slug in prefs.items():
 cs=sorted([c for c in data['courses'] if c['area'].startswith(pref)],key=lambda c:c['name']);n=len(cs)
 body=f'<p class="eyebrow">EXPLORE JAPAN · {slug.upper()}</p><h1>{pref}のゴルフコース</h1><p class="lead">掲載{n}コース。景色・食事・アクセス・予算・宿泊を、各コースの詳細ページで比較できます。</p><p class="muted">掲載施設の一覧です。{pref}の全施設を網羅するものではありません。利用制限・閉鎖情報も各ページに表示します。</p><ul class="course-grid">'+''.join(card(c,'../') for c in cs)+'</ul>'
 write(f'prefectures/{slug}.html',pref+'のゴルフ場一覧',f'{pref}の掲載{n}コースを紹介。交通・景色・食事・予算・宿泊をコースごとに確認できます。',body,[('全国','index.html'),(pref,f'prefectures/{slug}.html')])
body='<p class="eyebrow">EXPLORE JAPAN</p><h1>都道府県から、次のコースへ。</h1><p class="lead">全国47都道府県、掲載1,800コースの詳細ガイド。</p>'
for region,ps in regions:
 body+=f'<section><h2>{region}</h2><ul class="pref-grid">'+''.join(f'<li><a href="prefectures/{en.lower()}.html">{pref}<span>{sum(c["area"].startswith(pref) for c in by.values())}コース →</span></a></li>' for pref,en in ps)+'</ul></section>'
write('directory.html','全国47都道府県のゴルフ場一覧','全国1,800コースを都道府県別に探す。コースごとの特徴・交通・食事・料金・利用条件を確認。',body,[('全国','index.html'),('都道府県別一覧','directory.html')])
body='''<p class="eyebrow">ABOUT THIS GUIDE</p><h1>掲載情報の見方</h1><section><h2>コース選びのための編集ガイド</h2><p>全国の掲載1,800コースを、楽しみ方と都道府県から探せます。全ゴルフ場の網羅一覧ではありません。カテゴリは独自の編集選定で、公式順位や口コミ点数のランキングではありません。</p></section><section><h2>出典と確認日</h2><p>公式サイト・運営会社・ゴルフ連盟・予約サイト等を参照し、項目ごとに確認先と日付を記載します。リンクが開くことと、記載内容が現在も有効であることは別です。リンクの点検だけでは情報確認日を書き換えません。</p><p>取得できない項目や、条件を確定できない情報は「不明」とします。施設がないという意味ではありません。取得失敗時も、確認済みの既存情報を勝手に消したり置き換えたりしません。</p></section><section><h2>料金の比較</h2><p>同一日・同条件の最安値比較ではありません。18ホール、ハーフ、ショート、宿泊付きは分けて確認してください。食事、税、キャディ、カート、人数割増を含む予約日の総額は施設または予約先で確認が必要です。</p></section><section><h2>画像とおすすめ</h2><p>トップとカテゴリの画像はAI生成イメージで、特定の施設の実景ではありません。景色の見え方・季節の花・料理の提供内容は日程や天候で変わります。性別だけで難易度や楽しみ方は決まりません。</p></section><section><h2>保存・共有</h2><p>お気に入りは利用中のブラウザに保存されます。別端末には自動同期しません。各コースの詳細URLはそのまま共有できます。サイト上でのコース選択だけでは予約は成立しません。</p></section>'''
write('editorial.html','掲載方針・情報の見方','出典・確認日、料金の比較条件、未確認情報の扱い、画像と編集方針を説明します。',body,[('全国','index.html'),('掲載方針','editorial.html')])
for path,title,description in [('index.html','全国のゴルフコースガイド | GOLF GUTS','全国47都道府県・1,800コースを、景色・食事・交通・予算・宿泊から比較。コースごとの根拠と利用条件を確認できます。'),('find.html','４コースを見つける | GOLF GUTS','都道府県・交通・楽しみ方・優先したいことの4問から、全国のゴルフコース4件を比較。')]:
 p=D/path;s=p.read_text();url=origin+'/'+public_path(path)
 s=re.sub(r'<meta name="description"[^>]*>',f'<meta name="description" content="{description}">',s)
 s=re.sub(r'<!-- SEO START -->.*?<!-- SEO END -->','',s,flags=re.S)
 s=s.replace('</head>',f'<!-- SEO START --><link rel="canonical" href="{url}"><meta property="og:title" content="{title}"><meta property="og:description" content="{description}"><meta property="og:url" content="{url}"><meta property="og:type" content="website"><meta name="twitter:card" content="summary"><!-- SEO END --></head>')
 if path=='index.html':
  block='<section class="notice"><h2>コースの詳細を探す</h2><p>各コースの専用ページで、交通・食事・予算・利用条件を確認して、そのまま共有できます。</p><p><a href="directory.html">47都道府県のコース一覧 →</a>　<a href="editorial.html">掲載方針・情報の見方 →</a></p></section>'
  s=re.sub(r'<!-- DIRECTORY START -->.*?<!-- DIRECTORY END -->','',s,flags=re.S)
  s=s.replace('</main>','<!-- DIRECTORY START -->'+block+'<!-- DIRECTORY END --></main>')
  s=s.replace('全国版の掲載情報は2026年10月25日に更新。','掲載情報は項目ごとに確認・更新しています。')
 p.write_text(s);entries.append((url,None))
(D/'robots.txt').write_text(f'User-agent: *\nAllow: /\nSitemap: {origin}/sitemap.xml\n')
(D/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join('<url><loc>'+esc(url)+'</loc>'+('<lastmod>'+date+'</lastmod>' if date else '')+'</url>' for url,date in entries)+'</urlset>\n')
statefile.write_text(json.dumps(state,ensure_ascii=False,indent=2));print(json.dumps({'coursePages':len(by),'prefecturePages':len(prefs),'sitemapURLs':len(entries),'origin':origin}))
