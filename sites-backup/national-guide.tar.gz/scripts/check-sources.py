"""Read-only rotating source reachability audit. Never changes published facts or their dates."""
import json,urllib.parse,concurrent.futures,threading,time,argparse,hashlib,collections,subprocess,shutil
from pathlib import Path
from datetime import datetime,timezone
R=Path(__file__).resolve().parents[1]
def inventory():
 s=(R/'dist/data.js').read_text();d=json.loads(s[s.index('=')+1:].strip().rstrip(';'));out={}
 for c in d['courses']:
  pairs=[(k,c.get(k)) for k in ['officialUrl','bookingUrl','url']]+[(k,f.get('url')) for k,f in c.get('comparison',{}).items() if f]+[('source',x['url']) for x in c.get('sources',[])]
  for k,u in pairs:
   if not u:continue
   p=urllib.parse.urlsplit(u)
   if p.scheme not in ['http','https'] or p.username or p.password:raise ValueError('Unsafe source URL')
   u=urllib.parse.urlunsplit((p.scheme,p.netloc,p.path,p.query,''));out.setdefault(u,[]).append({'id':c['id'],'field':k})
 return out
parser=argparse.ArgumentParser();parser.add_argument('--limit',type=int,default=200);parser.add_argument('--workers',type=int,default=8);parser.add_argument('--timeout',type=float,default=8);parser.add_argument('--inventory-only',action='store_true');args=parser.parse_args()
assert shutil.which('curl'),'curl is required for bounded network checks'
urls=inventory();folder=R/'docs/maintenance';folder.mkdir(exist_ok=True);target=folder/'source-health.json';state=json.loads(target.read_text()) if target.exists() else {'records':{}};records=state['records'];keys=sorted(urls,key=lambda u:(records.get(u,{}).get('checkedAt',''),0 if any(x['field']=='officialUrl' for x in urls[u]) else 1,u))
if args.inventory_only:print(json.dumps({'uniqueURLs':len(keys),'previouslyChecked':len(set(keys)&set(records))}));raise SystemExit()
if args.limit>0:keys=keys[:args.limit]
# Interleave selected hosts: threads waiting on one host must not prevent
# unrelated hosts from being checked. Per-host concurrency remains capped at 2.
host_queues={}
for u in keys:host_queues.setdefault(urllib.parse.urlsplit(u).hostname,collections.deque()).append(u)
keys=[]
while host_queues:
 for host,q in list(host_queues.items()):
  keys.append(q.popleft())
  if not q:del host_queues[host]
semaphores={host:threading.Semaphore(2) for host in set(urllib.parse.urlsplit(u).hostname for u in keys)}
def check(u):
 host=urllib.parse.urlsplit(u).hostname
 with semaphores[host]:
  result={'checkedAt':datetime.now(timezone.utc).isoformat(),'code':None,'status':'unconfirmed','finalURL':u}
  try:
   # A socket timeout alone can be extended by slow reads/redirects. Bound the
   # entire transfer, including DNS, TLS and redirects, with curl + process timeout.
   r=subprocess.run(['curl','--silent','--show-error','--location','--max-redirs','5',
    '--max-time',str(args.timeout),'--connect-timeout',str(args.timeout),
    '--max-filesize','32768','--output','/dev/null','--user-agent','GOLFGUTS-SourceCheck/1.0',
    '--write-out','%{http_code}\n%{url_effective}\n%{content_type}\n%{size_download}',u],
    capture_output=True,text=True,timeout=args.timeout+2)
   parts=r.stdout.split('\n');code=int(parts[0] or 0);dest=parts[1] if len(parts)>1 else u
   status=('access_limited' if code in [401,403,429] else 'not_found' if code in [404,410]
           else 'server_error' if code>=500 else 'reachable' if 200<=code<300 and r.returncode in [0,63]
           else 'connection_error' if r.returncode else 'review')
   result.update(code=code or None,finalURL=dest,status=status,contentType=parts[2] if len(parts)>2 else '')
   if r.returncode:result['transferExit']=r.returncode
   if urllib.parse.urlsplit(dest).hostname!=host:result['redirectReview']=True
   if status=='reachable' and r.returncode==0 and len(parts)>3 and float(parts[3] or 0)==0:result['status']='empty_response'
  except Exception as e:result.update(status='connection_error',error=type(e).__name__)
  time.sleep(.15)
 return u,result
start=hashlib.sha256((R/'dist/data.js').read_bytes()).hexdigest()
def save():
 state.update(inventoryCount=len(urls),coverageCount=sum(u in records for u in urls),lastRun=datetime.now(timezone.utc).isoformat(),note='通信結果のみ。200は内容の正確性を保証せず、失敗は閉鎖を意味しない。掲載データ・情報確認日は変更しない。')
 temp=target.with_suffix('.tmp');temp.write_text(json.dumps(state,ensure_ascii=False,indent=2));temp.replace(target)
with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(args.workers,16))) as pool:
 futures=[pool.submit(check,u) for u in keys]
 for i,future in enumerate(concurrent.futures.as_completed(futures),1):
  u,result=future.result()
  records[u]=result
  if i%25==0:save();print(f'{i}/{len(keys)}',flush=True)
save();assert hashlib.sha256((R/'dist/data.js').read_bytes()).hexdigest()==start,'Fact data changed concurrently; audit did not write it'
counts=dict(collections.Counter(records[u]['status'] for u in keys));(folder/'source-last-run.json').write_text(json.dumps({'tested':len(keys),'total':len(urls),'results':counts,'at':state['lastRun']},ensure_ascii=False,indent=2));print(json.dumps({'tested':len(keys),'total':len(urls),'results':counts}))
