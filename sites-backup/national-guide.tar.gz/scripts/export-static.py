"""Prepare a portable static-site ZIP without modifying the live checkout."""
import argparse, hashlib, json, os, re, shutil, subprocess, tempfile, zipfile
from pathlib import Path

R = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--origin', required=True, help='Final HTTPS public URL, including repository subpath if used')
p.add_argument('--output', required=True, help='New ZIP path outside this checkout')
a = p.parse_args()
origin = a.origin.rstrip('/')
assert re.fullmatch(r'https://[A-Za-z0-9.-]+(?:/[A-Za-z0-9_-]+)*', origin), 'Invalid HTTPS origin'
output = Path(a.output).resolve()
assert output.suffix == '.zip' and not output.exists(), 'Use a new .zip path'
assert not output.is_relative_to(R), 'Export outside the source checkout'
data_hash = hashlib.sha256((R/'dist/data.js').read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='guts-static-') as tmp:
    stage = Path(tmp)
    for folder in ['dist', 'scripts', 'tests', 'docs/maintenance']:
        shutil.copytree(R/folder, stage/folder, ignore=shutil.ignore_patterns('__pycache__'))
    env = dict(os.environ, SITE_ORIGIN=origin, SITE_CLEAN_URLS='0')
    subprocess.run(['python', str(stage/'scripts/build-pages.py')], env=env, check=True)
    # The existing Sites analytics endpoint is origin-bound. Do not carry that
    # installation to another host or send visitor data to a different property.
    for page in (stage/'dist').rglob('*.html'):
        s = page.read_text()
        s = re.sub(r'<script\b[^>]*src=[\"\'][^\"\']*guts-analytics\.js[^\"\']*[\"\'][^>]*>\s*</script>', '', s)
        page.write_text(s)
    (stage/'dist/guts-analytics.js').unlink(missing_ok=True)
    (stage/'dist/.nojekyll').write_text('')
    subprocess.run(['python', str(stage/'tests/pages-check.py')], check=True)
    assert hashlib.sha256((stage/'dist/data.js').read_bytes()).hexdigest() == data_hash
    files = {str(f.relative_to(stage/'dist')): hashlib.sha256(f.read_bytes()).hexdigest()
             for f in sorted((stage/'dist').rglob('*')) if f.is_file()}
    manifest = {'origin': origin, 'courseCount': 1800, 'dataSha256': data_hash, 'files': files,
                'note': 'Prepared export only. Hosting, DNS, indexing and analytics are not configured.'}
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name in files:
            z.write(stage/'dist'/name, name)
        z.writestr('export-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
assert hashlib.sha256((R/'dist/data.js').read_bytes()).hexdigest() == data_hash
print(json.dumps({'export': str(output), 'files': len(files), 'origin': origin}))
