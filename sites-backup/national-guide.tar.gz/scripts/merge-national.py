import json,re,copy,sys,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'docs/research'
def readjs(p):
 s=Path(p).read_text();return json.loads(s[s.index('{'):].rstrip(';\n'))
def norm(n):
 n=n.replace('ミオス菊川','掛川')
 return re.sub(r'[\s・･　]','',unicodedata.normalize('NFKC',n)).replace('ゴルフクラブ','GC').replace('ゴルフ倶楽部','GC').replace('カントリークラブ','CC').replace('カンツリークラブ','CC').replace('カントリー倶楽部','CC').replace('カンツリー倶楽部','CC')
d=readjs(WORK/'nation-before-1800.js');k=readjs(ROOT/'docs/research/kanto-reference.js');m=json.loads((WORK/'kanto-national-map.json').read_text());base=copy.deepcopy(d['courses']);courses={c['id']:c for c in base};nextid=max(courses)+1
prefnames=[p[0] for r in json.loads((ROOT/'dist/regions.json').read_text()) for p in r[1]]
def pref(c):
 return next((p for p in prefnames if c['area'].startswith(p)),None)
retired={r['nationalId']:r for r in m['removals']}
retired[1354]={'nationalId':1354,'name':'鹿児島ゴルフリゾート','reason':'2022-02-01から長期休業の施設告知。再開を確認できないため除外。','url':'https://booking.gora.golf.rakuten.co.jp/guide/disp/c_id/460011/'}
retired[991]={'nationalId':991,'name':'南富士カントリークラブ','reason':'2024-09-30営業終了','url':'https://jgja.jp/202407019051/'}
for id in retired:courses.pop(id,None)
kmap={a['kantoId']:a['nationalId'] for a in m['matches']}
for cid in m['additions']:
 kmap[cid]=nextid;nextid+=1
for x in k['courses']:
 id=kmap[x['id']];old=courses.get(id,{});new=copy.deepcopy(x);new['id']=id
 if old.get('area') and len(old['area'])>len(new['area']):new['area']=old['area']
 for key in ['aspiration','tags']:
  if old.get(key):new[key]=old[key]
 courses[id]=new
keys=['play','car','rail','scenery','dining','budget','stay'];patchstats={};candidates=[];known={(pref(c),norm(c['name'])):id for id,c in courses.items()}
for region in ['north','chubu','kinki','chugoku','kyushu','kanto-extra']:
 file=WORK/('nation-'+region+'.json')
 if not file.exists():continue
 patch=json.loads(file.read_text());patch=patch.get('courses',[]) if isinstance(patch,dict) else patch
 patchstats[region]=len(patch)
 for x in patch:
  if x.get('id') in retired:continue
  identity=(pref(x),norm(x['name'])); id=x.get('id')
  if id in courses and pref(courses[id])==pref(x) and norm(courses[id]['name'])==norm(x['name']):pass
  else:id=known.get(identity)
  if id is not None:
   old=courses[id];new=copy.deepcopy(x);new['id']=id
   # Existing access restrictions and dream reasons remain authoritative.
   if old.get('aspiration'):new['aspiration']=old['aspiration']
   if old.get('tags') and not new.get('tags'):new['tags']=old['tags']
   courses[id]={**old,**new}
  else:
   if identity not in {i for i,_ in candidates}:candidates.append((identity,copy.deepcopy(x)))
# Add verified candidates with the richest factual coverage, balancing prefectures.
counts={p:sum(pref(c)==p for c in courses.values()) for p in prefnames}
selected=[]
while len(courses)<1800 and candidates:
 candidates.sort(key=lambda pair:(-sum(bool(v and v.get('text')) for v in pair[1].get('comparison',{}).values()),counts.get(pair[0][0],0),pair[1]['name']))
 identity,x=candidates.pop(0)
 if identity in known:continue
 x['id']=nextid;courses[nextid]=x;known[identity]=nextid;nextid+=1;counts[identity[0]]+=1;selected.append(x['name'])
for c in courses.values():
 c.setdefault('comparison',{})
 for key in keys:c['comparison'].setdefault(key,None)
 if not c.get('note'):c['note']='料金・営業日・プレースタイル・利用条件は予約前に確認してください。'
 if not c.get('feature'):c['feature']=c['comparison']['play']['text'] if c['comparison']['play'] else c['name']+'のコース案内。'
 c.setdefault('url',c.get('officialUrl'))
 assert pref(c),c['name']
 assert c.get('url'),c['name']
# Preserve categories and enrich their Kanto selections with the current reference.
for i,cat in enumerate(d['categories']):
 ids=[id for id in cat['ids'] if id in courses]
 if i<10:
  ids=list(dict.fromkeys([kmap[id] for id in k['categories'][i]['ids']]+ids))
 cat['ids']=ids;cat['reasons']=[courses[id].get('aspiration',{}).get('reason',courses[id]['feature']) if cat.get('key')=='dream' else courses[id]['feature'] for id in ids]
d['courses']=sorted(courses.values(),key=lambda c:c['id']);d['updated']='2026-10-25';d['retiredIds']=list(retired)
coverage={key:sum(bool(c['comparison'].get(key) and c['comparison'][key].get('text')) for c in courses.values()) for key in keys}
audit={'total':len(courses),'prefectures':counts,'populatedFields':coverage,'numericPriceCount':sum(c['comparison']['budget'] is not None and c['comparison']['budget'].get('priceVerified') is True for c in courses.values()),'retired':list(retired.values()),'regionalInputCounts':patchstats,'newSelected':selected,'unusedCandidates':len(candidates),'definition':'件数は掲載レコード数。値あり件数は全件の現在営業・情報正確性を保証しません。未確認値を推定で補いません。'}
(ROOT/'docs').mkdir(exist_ok=True);(ROOT/'docs/nation-1800-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
(ROOT/'dist/data.js').write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
print(json.dumps(audit,ensure_ascii=False,indent=2))
if '--final' in sys.argv:assert len(courses)==1800
