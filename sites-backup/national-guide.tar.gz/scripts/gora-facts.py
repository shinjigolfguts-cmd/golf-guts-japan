import json,re,unicodedata,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];CACHE=ROOT/'docs/research/gora-facts-input.json'
JP=['北海道','青森県','岩手県','宮城県','秋田県','山形県','福島県','茨城県','栃木県','群馬県','埼玉県','千葉県','東京都','神奈川県','新潟県','富山県','石川県','福井県','山梨県','長野県','岐阜県','静岡県','愛知県','三重県','滋賀県','京都府','大阪府','兵庫県','奈良県','和歌山県','鳥取県','島根県','岡山県','広島県','山口県','徳島県','香川県','愛媛県','高知県','福岡県','佐賀県','長崎県','熊本県','大分県','宮崎県','鹿児島県','沖縄県']
def norm(n):
 n=unicodedata.normalize('NFKC',n);n=re.sub(r'【[^】]*】|\([^)]*\)|（[^）]*）','',n);n=re.sub(r'[\s・･　]','',n).lower()
 for a,b in [('ゴルフクラブ','gc'),('ゴルフ倶楽部','gc'),('カントリークラブ','cc'),('カンツリークラブ','cc'),('カントリー倶楽部','cc'),('カンツリー倶楽部','cc')]:n=n.replace(a,b)
 return n
s=(ROOT/'dist/data.js').read_text();d=json.loads(s[s.index('{'):].rstrip(';\n'));byname=collections.defaultdict(list)
for c in d['courses']:byname[norm(c['name'])].append(c)
counts=collections.Counter();issues=[];matched=set();maprecords=[]
terrain={'hill':'丘陵','forest':'林間','mountain':'山岳','river':'河川敷','seaside':'シーサイド','plateau':'高原'}
elevation={'flat':'フラット','moderate_up_down':'適度なアップダウン','mountain':'山岳地形'}
for v in json.loads(CACHE.read_text()):
 g=v['data'];name=g['basic']['name']['primary'];code=g['basic']['address']['regionId'];pref=JP[int(code[-2:])-1] if code and code.startswith('JP-') else None
 matches=byname.get(norm(name),[])
 if not matches:matches=byname.get(norm(v['listingName']),[])
 matches=[c for c in matches if pref and c['area'].startswith(pref)]
 if len(matches)!=1:continue
 c=matches[0];matched.add(c['id']);url=v['url'];cmp=c['comparison'];o=g['course']['overview'];
 if o.get('totalHoles')==9 and '9H' not in c.get('badge',''):c['badge']='9H'+(' / '+c['badge'] if c.get('badge') else '')
 mapping={'id':c['id'],'goraId':g['golfCourseId'],'name':name,'prefecture':pref,'url':url};maprecords.append(mapping)
 def put(key,text,**extra):
  if cmp.get(key) or not text:return
  cmp[key]={'text':text,'url':url,'checked':'2026-10-25','basis':'楽天GORAの当施設掲載情報（施設公式サイトとは別）','sourceType':'booking',**extra};counts[key]+=1
 parts=[]
 if isinstance(o.get('totalHoles'),int) and 3<=o['totalHoles']<=108:parts.append(str(o['totalHoles'])+'ホール')
 if isinstance(o.get('par'),int) and o['par']>0:parts.append('パー'+str(o['par']))
 if o.get('terrainType') in terrain:parts.append(terrain[o['terrainType']]+'コース')
 if o.get('elevationType') in elevation:parts.append(elevation[o['elevationType']])
 if parts:
  text='・'.join(parts)+'。'
  designer=o.get('designer')
  if designer and len(designer)<70:text+='設計：'+designer.replace('\n',' ')+'。'
  pr=g['facility'].get('practiceRange',{})
  if isinstance(pr.get('distance'),(int,float)) and pr['distance']>0 and isinstance(pr.get('capacity'),int) and pr['capacity']>0:text+='練習場は'+str(pr['distance'])+'ヤード・'+str(pr['capacity'])+'打席の掲載。'
  put('play',text)
 car=g['access']['car'];routes=[]
 for a in car.get('list',[]):
  if a.get('highwayName') and a.get('interchangeName') and isinstance(a.get('distance'),(int,float)) and 0<a['distance']<=100:
   routes.append(a['highwayName']+'・'+a['interchangeName']+'ICから'+str(a['distance'])+'km以内')
 if routes:put('car','／'.join(routes[:3])+'と掲載。距離区分で、所要時間を示すものではありません。')
 memo=g['facility'].get('service',{}).get('transportation',{}).get('memo','') or ''
 if re.fullmatch(r'\s*(なし|無し|ありません)[。．]?\s*',memo):put('rail','クラブバスはなしと掲載されています。駅からのタクシー等の移動手段は予約前に確認してください。')
 # Do not infer a station, shuttle, hotel, spring, menu or price from absence or from nearby advertisements.
 amenity=g['facility'].get('amenity',{}).get('list',[]);stay=[]
 if any(a.get('code')=='overnight_stay' and a.get('isAvailable') is True for a in amenity):stay.append('宿泊施設あり')
 if any(a.get('code')=='hotspring' and a.get('isAvailable') is True for a in amenity):stay.append('温泉あり')
 if stay:put('stay','楽天GORAの設備欄に'+'・'.join(stay)+'と掲載。営業日・宿泊プラン・入浴条件は予約時に確認してください。')
 if len(c['area'])<=4 and pref and g['basic']['address'].get('street'):c['area']=pref+'・'+g['basic']['address']['street']
 if not any(a.get('url')==url for a in c.get('sources',[])):c.setdefault('sources',[]).append({'label':'楽天GORAの施設案内','url':url})
 notice=g.get('urgentNotice',{})
 if notice.get('publicStatus') and notice.get('content'):issues.append({'id':c['id'],'name':c['name'],'urgentNotice':notice['content'],'url':url})
# Replace stale generic registry descriptions by factual course characteristics without changing authored recommendations.
for c in d['courses']:
 if c['comparison'].get('play') and re.search('加盟団体|加盟一覧|ゴルフ連盟|連盟一覧|登録を確認|所在を確認|登録コース|にあるゴルフコース|にあるゴルフ場|のコース案内。',c.get('feature','')):c['feature']=c['comparison']['play']['text']
for cat in d['categories']:cat['reasons']=[next(c for c in d['courses'] if c['id']==id).get('feature','') for id in cat['ids']]
(ROOT/'dist/data.js').write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n')
(ROOT/'docs/gora-supplement-map.json').write_text(json.dumps(maprecords,ensure_ascii=False,indent=2));(ROOT/'docs/gora-notices-to-review.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2));print('matched',len(matched),'added fields',dict(counts),'urgent notices',len(issues))
