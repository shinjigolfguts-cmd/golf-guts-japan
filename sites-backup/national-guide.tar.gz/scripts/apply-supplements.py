import json,re,unicodedata,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'docs/research'
def norm(n):
 n=unicodedata.normalize('NFKC',n);n=re.sub(r'【[^】]*】|\([^)]*\)|（[^）]*）','',n);n=re.sub(r'[\s・･　]','',n).lower()
 for a,b in [('ゴルフクラブ','gc'),('ゴルフ倶楽部','gc'),('カントリークラブ','cc'),('カンツリークラブ','cc'),('カントリー倶楽部','cc'),('カンツリー倶楽部','cc')]:n=n.replace(a,b)
 return n
s=(ROOT/'dist/data.js').read_text();d=json.loads(s[s.index('{'):].rstrip(';\n'));counts=collections.Counter();unmatched=[]
for file in W.glob('gora-*-extra.json'):
 for row in json.loads(file.read_text()):
  matches=[c for c in d['courses'] if norm(c['name'])==norm(row['name']) and c['area'].startswith(row['pref'])]
  if len(matches)!=1:unmatched.append(row['name']);continue
  c=matches[0]
  for key,f in row['comparison'].items():
   if f and not c['comparison'].get(key):c['comparison'][key]=f;counts[key]+=1
restrictions=W/'gora-restrictions.json'
if restrictions.exists():
 for row in json.loads(restrictions.read_text()):
  matches=[c for c in d['courses'] if norm(c['name'])==norm(row['name']) and c['area'].startswith(row['pref'])]
  if len(matches)!=1:unmatched.append(row['name']);continue
  c=matches[0];c['comparison'][row['field']]=row['override']
  if row.get('note'):c['note']=row['note']+' '+c['note'];c['serviceNotice']=row['note']
  if row['field']=='play':c['feature']=row['override']['text']
  if row['field']=='stay' and '営業を終了' in row['override']['text']:
   c['serviceNotice']=row['override']['text']
 for row in json.loads(restrictions.read_text()):
  if row['field']=='stay' and '営業を終了' in row['override']['text']:
   ids={c['id'] for c in d['courses'] if norm(c['name'])==norm(row['name']) and c['area'].startswith(row['pref'])}
   d['categories'][7]['ids']=[id for id in d['categories'][7]['ids'] if id not in ids]
for c in d['courses']:
 if c['name'] in ['パインレークゴルフクラブ','レイクグリーンゴルフ倶楽部','斑尾東急ゴルフクラブ'] and c['comparison'].get('play'):c['feature']=c['comparison']['play']['text']
 if c.get('officialUrl') and re.search(r'(?:gora\.golf\.rakuten|golfdigest|kga\.gr|cgu\.gr|jga\.or|tga\.gr|guk\.or|shotnavi)',c['officialUrl']):c['officialUrl']=None
 booking=next((x['url'] for x in c.get('sources',[]) if 'booking.gora.golf.rakuten.co.jp' in x['url']),None)
 if booking:c['bookingUrl']=booking
 if c.get('officialUrl') and not c['officialUrl'].startswith(('https://','http://')):raise ValueError(c['name'])
# Keep authored Kanto category-specific reasons; all other entries use their own verified feature.
k=json.loads(Path(ROOT/'docs/research/kanto-reference.js').read_text().removeprefix('const DATA=').rstrip(';\n'));m=json.loads((W/'kanto-national-map.json').read_text());kmap={a['kantoId']:a['nationalId'] for a in m['matches']}
for i,cat in enumerate(d['categories']):
 lookup={kmap[id]:reason for id,reason in zip(k['categories'][i]['ids'],k['categories'][i]['reasons']) if id in kmap} if i<10 else {}
 cat['reasons']=[c.get('aspiration',{}).get('reason',c['feature']) if cat.get('key')=='dream' else (c['feature'] if c.get('serviceNotice') else lookup.get(id,c['feature'])) for id in cat['ids'] for c in [next(c for c in d['courses'] if c['id']==id)]]
# All seven display positions exist even when no trustworthy source is available.
coverage={key:sum(bool(c['comparison'].get(key)) for c in d['courses']) for key in ['play','car','rail','scenery','dining','budget','stay']}
audit=json.loads((ROOT/'docs/nation-1800-audit.json').read_text());audit['populatedFields']=coverage;audit['numericPriceCount']=sum(bool(c['comparison'].get('budget',{}) and c['comparison']['budget'].get('priceVerified')) for c in d['courses']);audit['descriptiveSupplementCounts']=dict(counts);audit['unmatchedSupplementNames']=unmatched;audit['restrictionUpdates']=len(json.loads(restrictions.read_text())) if restrictions.exists() else 0
(ROOT/'docs/nation-1800-audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));(ROOT/'dist/data.js').write_text('const DATA='+json.dumps(d,ensure_ascii=False,separators=(',',':'))+';\n');print('coverage',coverage,'unmatched',unmatched)

# Preserve independently verified corrections when regenerating supplements.
import subprocess,sys
subprocess.run([sys.executable,str(ROOT/"scripts/apply-audit-corrections.py")],check=True)
