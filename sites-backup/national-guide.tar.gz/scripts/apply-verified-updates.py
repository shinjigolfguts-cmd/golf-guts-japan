"""Apply reviewed, evidence-backed field updates with optimistic concurrency. Dry-run by default."""
import argparse,json,hashlib,re,os
from pathlib import Path
from datetime import date,datetime
from zoneinfo import ZoneInfo
R=Path(__file__).resolve().parents[1]
def apply(data_bytes,patch):
 if hashlib.sha256(data_bytes).hexdigest()!=patch['baseSha256']:raise ValueError('Source changed; rebase and review the patch before applying')
 text=data_bytes.decode();data=json.loads(text[text.index('=')+1:].strip().rstrip(';'));by={c['id']:c for c in data['courses']};seen=set();changes=[]
 for u in patch['updates']:
  c=by.get(u['id']);key=u['field'];assert c and c['name']==u['name'],'Identity mismatch'
  assert key in ['play','car','rail','scenery','dining','stay','budget'],'Invalid field'
  assert (u['id'],key) not in seen,'Duplicate update';seen.add((u['id'],key))
  assert c['comparison'][key]==u['before'],'Field changed since research'
  f=u['after'];assert f and isinstance(f.get('text'),str) and f['text'].strip(),'Cannot delete or blank a fact'
  assert re.match(r'^https?://[^\s]+$',f.get('url','')),'Evidence URL required'
  checked=date.fromisoformat(f['checked']);assert checked<=datetime.now(ZoneInfo('Asia/Tokyo')).date(),'Future verification date'
  assert f.get('sourceType') in ['official','booking','review','association'],'Source type required'
  assert u.get('evidenceNote') and len(u['evidenceNote'])>=10,'Explicit reviewed evidence required'
  if f.get('priceVerified'):assert re.search(r'\d',f.get('priceLabel','')) and f.get('conditions'),'Price conditions required'
  if f!=u['before']:c['comparison'][key]=f;changes.append(u)
 # Overall date only moves for an actual change; failed reads never become patches.
 if changes:data['updated']=max([data.get('updated',''),*[x['after']['checked'] for x in changes]])
 return ('const DATA='+json.dumps(data,ensure_ascii=False,separators=(',',':'))+';\n').encode(),changes
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('patch');p.add_argument('--apply',action='store_true');a=p.parse_args();target=R/'dist/data.js';before=target.read_bytes();out,changes=apply(before,json.loads(Path(a.patch).read_text()));print(json.dumps({'mode':'apply' if a.apply else 'dry-run','changedFields':len(changes)}))
 if a.apply and changes:
  assert target.read_bytes()==before,'Concurrent change before commit'
  temp=target.with_suffix('.tmp');temp.write_bytes(out);os.replace(temp,target)
