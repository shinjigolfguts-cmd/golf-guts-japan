import importlib.util,json,hashlib,copy
from pathlib import Path
R=Path(__file__).resolve().parents[1];spec=importlib.util.spec_from_file_location('updater',R/'scripts/apply-verified-updates.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
b=b'const DATA={"courses":[{"id":1,"name":"Example","comparison":{"rail":null}}],"updated":"2026-10-25"};\n'
f={'text':'Confirmed station route','url':'https://example.com/access','checked':'2026-10-26','sourceType':'official'}
p={'baseSha256':hashlib.sha256(b).hexdigest(),'updates':[{'id':1,'name':'Example','field':'rail','before':None,'after':f,'evidenceNote':'Reviewed official route and conditions'}]}
out,changes=m.apply(b,p);assert len(changes)==1 and json.loads(out.decode()[11:].strip().rstrip(';'))['courses'][0]['comparison']['rail']==f
for kind in ['hash','name','before','empty','price','date']:
 q=copy.deepcopy(p)
 if kind=='hash':q['baseSha256']='bad'
 elif kind=='name':q['updates'][0]['name']='Other'
 elif kind=='before':q['updates'][0]['before']={}
 elif kind=='empty':q['updates'][0]['after']=None
 elif kind=='price':q['updates'][0]['after']['priceVerified']=True
 else:q['updates'][0]['after']['checked']='2099-01-01'
 try:m.apply(b,q)
 except (AssertionError,ValueError):pass
 else:raise AssertionError('accepted invalid '+kind)
assert (R/'dist/data.js').exists();print('Updater rejects stale source, wrong identity, changed field, blank facts, unqualified prices and future dates')
