// Run isolated Python checks so no live reachability ledger is changed.
const {execFileSync}=require('child_process');
execFileSync('python',['-c',String.raw`
from pathlib import Path
import tempfile,shutil,subprocess,sys,runpy,json,types
root=Path.cwd()
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp);(p/'scripts').mkdir();(p/'dist').mkdir();(p/'docs/maintenance').mkdir(parents=True)
 shutil.copy(root/'scripts/check-sources.py',p/'scripts/check-sources.py')
 shutil.copy(root/'dist/data.js',p/'dist/data.js');before=(p/'dist/data.js').read_bytes();calls=[]
 real=subprocess.run
 def fake(args,**kwargs):
  assert '--max-time' in args and kwargs['timeout']==10
  calls.append(args[-1]);i=len(calls)
  if i==3:raise subprocess.TimeoutExpired(args,10)
  return types.SimpleNamespace(stdout=('200' if i==1 else '403')+'\n'+args[-1]+'\ntext/html\n100',returncode=0)
 subprocess.run=fake;sys.argv=['check-sources.py','--limit','3','--workers','1','--timeout','8']
 try:runpy.run_path(str(p/'scripts/check-sources.py'),run_name='__main__')
 finally:subprocess.run=real
 report=json.loads((p/'docs/maintenance/source-last-run.json').read_text())
 assert report['results']=={'reachable':1,'access_limited':1,'connection_error':1},report
 assert (p/'dist/data.js').read_bytes()==before
 print('Bounded source audit classifies success, denied and timeout without changing facts')
`],{stdio:'inherit'});
