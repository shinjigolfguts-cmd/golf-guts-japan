"""Verify export portability and that preparing it cannot rewrite live content."""
import hashlib,json,re,subprocess,tempfile,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def snapshot():
 return {str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest()
         for folder in ['dist','docs/maintenance'] for p in (R/folder).rglob('*') if p.is_file()}
before=snapshot()
with tempfile.TemporaryDirectory() as tmp:
 out=Path(tmp)/'export.zip'
 subprocess.run(['python',str(R/'scripts/export-static.py'),'--origin','https://example.invalid/golf-guide','--output',str(out)],check=True)
 with zipfile.ZipFile(out) as z:
  names=z.namelist()
  assert '.nojekyll' in names
  assert not any(n.startswith(('.git/','.openai/')) for n in names)
  manifest=json.loads(z.read('export-manifest.json'))
  for name,digest in manifest['files'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
  for name in names:
   if name.endswith('.html'):
    s=z.read(name).decode()
    assert not re.search(r'(?:href|src)=[\"\']/(?!/)',s),name
    assert 'guts-analytics.js' not in s,name
    assert 'rel="canonical" href="https://example.invalid/golf-guide/' in s,name
  assert z.read('data.js')==(R/'dist/data.js').read_bytes()
 assert snapshot()==before,'Export modified source checkout'
print('Static export: subpath links, correct origin, manifest integrity, unchanged live source passed')
