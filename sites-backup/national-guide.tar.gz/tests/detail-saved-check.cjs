const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');
let stored='[]';const events={},button={dataset:{save:'305'},setAttribute(k,v){this[k]=v}},status={};
const context={document:{querySelector:s=>s==='[data-save]'?button:null,getElementById:()=>status},
 localStorage:{getItem:()=>stored,setItem:(k,v)=>{stored=v}},window:{addEventListener:(n,f)=>{events[n]=f}}};
vm.createContext(context);vm.runInContext(fs.readFileSync('dist/course-page.js','utf8'),context);
assert.equal(button['aria-pressed'],'false');stored='[305,307]';events.pageshow();
assert.equal(button['aria-pressed'],'true');button.onclick();assert.deepEqual(JSON.parse(stored),[307]);
console.log('Detail page restored from browser history reflects newest favorites and preserves other courses');
