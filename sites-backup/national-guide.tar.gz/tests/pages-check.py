from pathlib import Path
from html.parser import HTMLParser
import json,re,urllib.parse,xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1];D=R/'dist'
class P(HTMLParser):
 def __init__(self):super().__init__();self.links=[];self.canonical=[];self.ids=[];self.h1=0
 def handle_starttag(self,t,attrs):
  a=dict(attrs)
  if t=='h1':self.h1+=1
  if t in ['a','link','script','img']:
   u=a.get('href') or a.get('src')
   if u:self.links.append(u)
  if t=='link' and a.get('rel')=='canonical':self.canonical.append(a['href'])
  if 'id' in a:self.ids.append(a['id'])
files=list(D.rglob('*.html'));canon=set()
for p in files:
 s=p.read_text();h=P();h.feed(s);assert len(h.canonical)==1,p
 assert h.canonical[0] not in canon,p;canon.add(h.canonical[0]);assert len(h.ids)==len(set(h.ids)),p
 if p.name not in ['find.html']:assert h.h1==1,p
 assert '<meta name="description"' in s,p
 for u in h.links:
  if u.startswith(('https:','http:','mailto:','tel:','#')):continue
  path=urllib.parse.urlsplit(u).path
  q=(D/path.lstrip('/')) if path.startswith('/') else p.parent/path
  if q.is_dir():q=q/'index.html'
  assert q.exists(),(p,u)
 for raw in re.findall(r'<script type="application/ld\+json">(.*?)</script>',s,re.S):json.loads(raw)
root=ET.fromstring((D/'sitemap.xml').read_text());ns={'s':'http://www.sitemaps.org/schemas/sitemap/0.9'};urls=[e.text for e in root.findall('.//s:loc',ns)];assert len(urls)==len(set(urls));assert len(list((D/'courses').glob('*.html')))==1800;assert len(list((D/'prefectures').glob('*.html')))==47
assert not any('/courses/1265' in x for x in urls);assert 'noindex,follow' in (D/'courses/1265.html').read_text()
assert len(urls)==1850;print(f'{len(files)} HTML pages: unique canonical, metadata, local links, IDs, JSON-LD, 1,850 sitemap URLs verified')
